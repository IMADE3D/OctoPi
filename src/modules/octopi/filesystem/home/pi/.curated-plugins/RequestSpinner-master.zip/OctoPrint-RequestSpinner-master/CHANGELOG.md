# OctoPrint-RequestSpinner Changelog

## 0.1.1 (2015-07-08)

### Bug Fixes

  * Fixed wrong URL for LESS asset.

## 0.1.0 (2015-06-21)

Initial release
