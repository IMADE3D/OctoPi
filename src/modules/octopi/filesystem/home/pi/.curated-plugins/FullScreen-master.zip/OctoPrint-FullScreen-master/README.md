# OctoPrint-Fullscreen

This plugin will allow you to open the webcam feed in fullscreen mode by double clicking the image. It will show a bar at the bottom of the image with information about print time, remaining time, temperatures and a pause button.

## Setup

Install via the bundled [Plugin Manager](https://github.com/foosel/OctoPrint/wiki/Plugin:-Plugin-Manager)
or manually using this URL:

    https://github.com/BillyBlaze/OctoPrint-FullScreen/archive/master.zip


## Support browsers (tested)
- IE Edge
- Firefox
- Chrome
