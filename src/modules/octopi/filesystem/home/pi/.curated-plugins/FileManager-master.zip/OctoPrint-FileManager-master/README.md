# OctoPrint-FileManager

## Setup

Install via the bundled [Plugin Manager](https://github.com/foosel/OctoPrint/wiki/Plugin:-Plugin-Manager)
or manually using this URL:

    https://github.com/Salandora/OctoPrint-FileManager/archive/master.zip
